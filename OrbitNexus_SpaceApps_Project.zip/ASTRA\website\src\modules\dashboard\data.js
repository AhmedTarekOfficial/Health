// OrbitNexus NASA Flight Surgeon Clinical Fixtures & Aerospace Standards
export const vitals = [
  {
    id: 'heart',
    name: 'Resting Heart Rate',
    value: '72.0',
    unit: 'BPM',
    icon: 'heart',
    note: 'Nominal (Target 60–85 BPM)',
    source: 'Optical Dual-Wavelength PPG @ 125 Hz',
    description: 'Continuous ventricular chronotropic frequency inferred from pulsatile radial photoplethysmography. In microgravity, cardiac stroke work decreases by ~15% due to reduced lower-body hydrostatic blood column pressure.',
    points: '0,23 12,21 20,23 27,8 34,29 41,15 48,21 60,21 69,18 80,21 90,16 100,20'
  },
  {
    id: 'oxygen',
    name: 'Arterial Oxygen Saturation (SpO2)',
    value: '98.6',
    unit: '%',
    icon: 'droplet',
    note: 'Sea-level PO2 Equivalent',
    source: 'Transcutaneous Pulse Oximeter',
    description: 'Fraction of oxygen-saturated hemoglobin relative to total hemoglobin. Critical for detecting insidious hypobaric hypoxia in pressurized space vehicle cabins and extravehicular mobility units (EMU).',
    points: '0,20 12,21 24,19 35,21 47,16 60,18 73,14 84,17 100,14'
  },
  {
    id: 'temperature',
    name: 'Core Body Temperature',
    value: '36.85',
    unit: '°C',
    icon: 'temperature',
    note: 'Temporal Heat-Flux Normal',
    source: 'Double-Sensor Pre-Auricular Heat Flux',
    description: 'Deep core thermal equilibrium measured via dual-sensor heat flux thermometry. In microgravity, natural convective cooling is abolished, predisposing astronauts to spaceflight-associated exercise hyperthermia.',
    points: '0,23 13,20 22,22 34,18 43,19 55,16 68,18 80,15 90,18 100,15'
  },
  {
    id: 'water',
    name: 'Total Body Water / Hydration Index',
    value: '62.4',
    unit: '% TBW',
    icon: 'droplet',
    note: 'Cephalad Fluid Shift -1.8L',
    source: 'Multi-Frequency Bioimpedance (BIS)',
    description: 'Continuous bioimpedance spectroscopy measuring extracellular and intracellular fluid volumes. Accurately quantifies microgravity cephalad fluid redistribution, plasma volume contraction, and dehydration trajectory.',
    points: '0,22 15,22 30,21 45,20 60,21 75,21 90,20 100,21'
  },
  {
    id: 'pressure',
    name: 'Continuous Arterial Blood Pressure',
    value: '118/76',
    unit: 'mmHg',
    icon: 'pulse',
    note: 'MAP: 90 mmHg (Normotensive)',
    source: 'Tonometric Non-Invasive Continuous BP',
    description: 'Aortic pressure waveform reconstruction. Eliminates gravity-dependent hydrostatic pressure gradient between head and feet, preventing lower-extremity vascular pooling and altering carotid baroreflex sensitivity.',
    points: '0,18 15,16 30,22 45,15 60,20 75,17 90,19 100,18'
  },
  {
    id: 'respiration',
    name: 'Ventilatory Respiration Rate',
    value: '16.2',
    unit: 'brpm',
    icon: 'activity',
    note: 'Eupneic (Target 12–20 brpm)',
    source: 'Transthoracic Impedance Pneumography',
    description: 'Transthoracic impedance plethysmography tracking respiratory frequency. Monitors alveolar ventilation-perfusion matching and provides early warning for localized carbon dioxide (CO2) pocket inhalation.',
    points: '0,21 16,14 32,24 48,15 64,22 80,16 100,20'
  },
  {
    id: 'hrv',
    name: 'Autonomic HRV (RMSSD)',
    value: '48.5',
    unit: 'ms',
    icon: 'pulse',
    note: 'Sympathovagal Balance: 1.15',
    source: 'ECG/PPG Inter-Beat Interval (IBI)',
    description: 'Root Mean Square of Successive RR interval Differences. Clinical gold standard for assessing parasympathetic vagal tone, high cognitive workload, allostatic overload, and physical exertion recovery.',
    points: '0,24 20,18 40,25 60,16 80,22 100,18'
  }
];

export const modelsInfo = [
  {
    id: 'activity',
    name: 'Physical Activity Recognition',
    dataset: 'PAMAP2 Dataset (UCI Benchmark)',
    metric: '99.62% Test Accuracy (Macro F1: 0.994)',
    badge: 'Random Forest GPU (100 Trees)',
    current: 'Resting / Nominal Metabolic IVA',
    inputVector: '22-Dimensional IMU Tensor (Wrist, Chest, Ankle @ 100 Hz)',
    latency: '0.78 ms',
    description: 'Ensemble Random Forest classifier mapping 3 wearable 9-DoF IMUs (accelerometers, gyroscopes, magnetometers) into 12 standardized physical activities with sub-millisecond on-device latency.'
  },
  {
    id: 'stress',
    name: 'Cognitive Stress & Autonomic Tone',
    dataset: 'WESAD Multimodal Physio Suite',
    metric: '89.67% Test Accuracy (Cohen Kappa: 0.862)',
    badge: 'XGBoost Multiclass',
    current: 'Autonomic Equilibrium (EDA: 2.15 µS)',
    inputVector: '5-Channel Physio Vector (HR, HRV-RMSSD, EDA, Skin Temp, Resp)',
    latency: '0.65 ms',
    description: 'Gradient-boosted decision trees classifying sympathetic nervous system arousal versus baseline and recovery states, preventing astronaut cognitive overload during high-tempo orbital operations.'
  },
  {
    id: 'heart',
    name: 'PPG Continuous Heart Rate Estimator',
    dataset: 'BIDMC Pulse Oximeter Waveform',
    metric: 'MAE: 1.10 BPM (Pearson r: 0.988)',
    badge: 'RF Regressor + Kalman Filter',
    current: '72.4 BPM Reconstructed',
    inputVector: '9 Morphological Peak & Spectral Frequency Features (125 Hz)',
    latency: '0.45 ms',
    description: 'Non-linear regression engine inferring continuous instantaneous heart rate directly from raw photoplethysmogram waveforms, maintaining clinical accuracy through astronaut motion artifacts.'
  },
  {
    id: 'anomaly',
    name: 'Physiological Anomaly & Divergence',
    dataset: 'ISS Simulation Biosuite (Zero-Day)',
    metric: 'Unsupervised Outlier Isolation (Contam: 0.05)',
    badge: 'Isolation Forest',
    current: 'NOMINAL ENVELOPE (Score: +0.142)',
    inputVector: '5D Spaceflight Vital Space (HR, SpO2, Resp, BP, Temp)',
    latency: '0.35 ms',
    description: 'Unsupervised multidimensional tree isolation detecting unexpected physiological drift, acute hypoxia, cardiac arrhythmia, and hypothermia before symptoms clinically manifest.'
  },
  {
    id: 'space_bio',
    name: 'Spaceflight Adaptation Genomics',
    dataset: 'NASA GeneLab OSD-178 (Spaceflight vs Ground)',
    metric: '100.0% Validation Accuracy (AUC: 1.000)',
    badge: 'Support Vector Machine (RBF)',
    current: 'Active Orbital Adaptation Signature',
    inputVector: '50-Gene Space Radiation Transcriptomic Signature',
    latency: '0.90 ms',
    description: 'Translational bioinformatics classifier identifying spaceflight biological adaptation signatures (DNA repair pathways CDKN1A, GADD45A, SOD2) against cosmic radiation and microgravity stress.'
  }
];

export const diseaseRisks = [
  {
    id: 'cardio_deconditioning',
    name: 'Cardiovascular Deconditioning & Orthostatic Intolerance',
    category: 'Cardiovascular / Hemodynamics',
    severity: 'NOMINAL',
    score: '12 / 100',
    biomarkers: 'HR: 72.4 bpm | HRV: 48.5 ms | BP: 118/76 mmHg | MAP: 90 mmHg',
    mechanism: 'Cephalad fluid redistribution (~1.8L) reduces lower-extremity transmural pressure, downregulates baroreceptor sensitivity, and induces left-ventricular cardiac mass remodeling, precipitating post-flight presyncope.',
    protocol: 'Mandatory 45-min daily ARED cycle ergometer session; lower-body negative pressure (LBNP) suit conditioning (-25 mmHg); 1.0L oral isotonic electrolyte loading 2 hours prior to atmospheric entry.'
  },
  {
    id: 'hypoxia_respiratory',
    name: 'Hypoxia & Alveolar V/Q Mismatch',
    category: 'Pulmonary / Cabin Life Support',
    severity: 'NOMINAL',
    score: '8 / 100',
    biomarkers: 'SpO2: 98.6% | Resp: 16.2 brpm | Cabin PO2: 21.0% | ppCO2: 2.8 mmHg',
    mechanism: 'Absence of gravity-dependent hydrostatic pleural gradients causes non-uniform alveolar expansion and regional ventilation-perfusion mismatch; localized microgravity air stagnation can induce carbon dioxide micro-pockets.',
    protocol: 'Automated cabin atmosphere scrubbing enhancement; emergency mask donning with supplemental 100% O2 delivery; metabolic workload reduction.'
  },
  {
    id: 'sans_neuro_ocular',
    name: 'Spaceflight-Associated Neuro-Ocular Syndrome (SANS)',
    category: 'Neuro-Ophthalmology / Intracranial Pressure',
    severity: 'MONITORED',
    score: '24 / 100',
    biomarkers: 'Cephalad Shift: +1.8L | Blood Water: 62.4% | ICP Proxy: Monitored',
    mechanism: 'Persistent loss of gravitational downward venous drainage elevates internal jugular and intracranial pressures (ICP), inducing bilateral optic disc edema (Frisén Grade 1-2), choroidal folds, and hyperopic refractive shift.',
    protocol: 'Daily 30-min Russian Chibis LBNP protocol (-25 mmHg); bi-weekly optical coherence tomography (OCT) retinal nerve fiber layer (RNFL) mapping; venoconstrictive countermeasure evaluation.'
  },
  {
    id: 'microgravity_osteopenia',
    name: 'Microgravity Osteopenia & Hypercalciuric Nephrolithiasis',
    category: 'Musculoskeletal / Mineral Metabolism',
    severity: 'ACTIVE PROTOCOL',
    score: '42 / 100',
    biomarkers: 'Axial Loading Index: 42/100 | TBW Hydration: 62.4% | Calciuria: Monitored',
    mechanism: 'Complete mechanical skeletal unloading suppresses osteocytic Wnt/beta-catenin signaling and accelerates osteoclastic resorption, producing 1.0–1.5% bone mineral density loss per month in load-bearing trabeculae and elevated calcium oxalate kidney stone risk.',
    protocol: 'Daily 45-min high-load axial loading on ARED (300 lb squats/deadlifts); monthly bisphosphonate/antiresorptive prophylaxis; strict 2.5L daily hydration target.'
  },
  {
    id: 'cosmic_radiation_dna',
    name: 'Cosmic Radiation Induced Clustered DNA Damage',
    category: 'Radiobiology / Genomic Integrity',
    severity: 'NOMINAL',
    score: '18 / 100',
    biomarkers: 'NASA GeneLab OSD-178 Index: 100% | Cumulative Dosimetry: 0.48 mSv/day',
    mechanism: 'Galactic Cosmic Rays (GCR) and Solar Particle Events (SPE) containing high-Z and high-energy (HZE) ions (56Fe, 28Si) produce complex clustered double-strand DNA breaks (DSBs) challenging endogenous non-homologous end joining (NHEJ).',
    protocol: 'Crew quarters water-wall polyethylene shielding; antioxidant dietary prophylaxis (N-acetylcysteine, alpha-lipoic acid); active silicon biodosimeter tracking.'
  },
  {
    id: 'dcs_hypothermia',
    name: 'EVA Acute Decompression Sickness & Hypothermia',
    category: 'EVA Operations / Environmental Physiology',
    severity: 'NOMINAL',
    score: '10 / 100',
    biomarkers: 'Core Temp: 36.85 °C | Skin Temp: 33.5 °C | Suit Delta-P: 4.3 psi',
    mechanism: 'Stepping down from 14.7 psi cabin pressure to 4.3 psi spacesuit pressure risks inert N2 gas phase bubble nucleation in periarticular tissues; extreme thermal radiation in orbit (-150°C in shadow) stresses suit thermoregulation.',
    protocol: 'NASA Campout Pre-Breathe Protocol (2.5 hr in-suit 100% O2 breathing at 10.2 psi airlock depression); automatic liquid cooling and ventilation garment (LCVG) closed-loop thermal regulation.'
  }
];

export const routines = [
  {
    title: 'NASA ARED Heavy Axial Loading Resistance',
    description: 'High-load skeletal osteogenic countermeasure (Squats/Deadlifts - 45 min)',
    time: '45 min'
  },
  {
    title: 'Chibis LBNP SANS Countermeasure Protocol',
    description: 'Lower Body Negative Pressure (-25 mmHg) to reverse cephalad venous congestion',
    time: '30 min'
  },
  {
    title: 'Bio-Telemetry Fluid & Saline Calibration',
    description: 'Hydration assessment & plasma volume equilibrium verification',
    time: '10 min'
  },
  {
    title: 'OrbitNexus Flight Surgeon Autonomous Triage',
    description: 'AI-assisted multi-sensor risk synthesis & crew health logging',
    time: '5 min'
  }
];
