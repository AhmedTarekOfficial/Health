from __future__ import annotations

from typing import Dict


class VoiceAssistant:
    """Browser-oriented voice interface wrapper for spoken responses and transcripts."""

    def __init__(self):
        self.voice_enabled = True

    def build_reply(self, text: str) -> Dict[str, object]:
        cleaned = (text or "").strip()
        if not cleaned:
            cleaned = "I am ready to help with the current telemetry."

        lower = cleaned.lower()
        if "heart rate" in lower or "hr" in lower:
            spoken = "Heart rate is being monitored. I recommend checking the trend and any sustained elevation against the current telemetry."
        elif "stress" in lower:
            spoken = "Stress appears elevated. Review recovery time, exertion, and rest periods before making a decision."
        elif "sleep" in lower:
            spoken = "Sleep quality is relevant to recovery. Check rest duration and fatigue markers in the current session."
        else:
            spoken = "I am listening. I will continue monitoring the astronaut health summary and key risk indicators."

        return {
            "voice_enabled": self.voice_enabled,
            "text": spoken,
            "transcript": cleaned,
        }
