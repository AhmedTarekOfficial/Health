import {
  vitals as defaultVitals,
  modelsInfo as defaultModels,
  diseaseRisks as defaultDiseases,
  routines
} from './data.js';
import { icon } from '../../shared/icons.js';

export const sparkline = points =>
  `<svg class="sparkline" viewBox="0 0 100 40" preserveAspectRatio="none" aria-hidden="true"><polyline points="${points}" fill="none" stroke="#c4c7d0" stroke-width="1.2"/></svg>`;

let currentVitals = JSON.parse(JSON.stringify(defaultVitals));
let currentModels = JSON.parse(JSON.stringify(defaultModels));
let currentDiseases = JSON.parse(JSON.stringify(defaultDiseases));
let realTimeInterval = null;
let currentMode = 'demo'; // 'demo' or 'realtime'
let smartwatchConnected = true;

export function initDashboard(showDialog, toast = () => {}) {
  renderVitals(showDialog);
  renderModels(showDialog);
  renderDiseases(showDialog);
  renderRoutines();
  renderChart('day');
  initModeAndWatchControls(toast);
  initOnlineLearning(toast);
}

// ── Vitals Rendering ────────────────────────────────────────────────────────
function renderVitals(showDialog) {
  const container = document.querySelector('#vital-cards');
  if (!container) return;
  container.innerHTML = currentVitals
    .map(
      v => `
    <button class="vital-card panel" data-metric="${v.id}" aria-label="${v.name}: ${v.value} ${v.unit}. View explanation">
      <span class="vital-label">
        ${icon(v.icon || 'pulse')}
        ${v.name}
        <span class="metric-arrow">${icon('arrowUpRight')}</span>
      </span>
      <span class="vital-value" id="val-${v.id}">
        ${v.value}<small>${v.unit}</small>
      </span>
      ${sparkline(v.points)}
      <span class="vital-status">
        <span class="status-dot"></span>
        <span id="note-${v.id}">${v.note}</span>
      </span>
    </button>`
    )
    .join('');

  document.querySelectorAll('[data-metric]').forEach(button =>
    button.addEventListener('click', () => {
      const v = currentVitals.find(item => item.id === button.dataset.metric);
      if (!v) return;
      showDialog(`
        <h2>${v.name}</h2>
        <div class="dialog-reading">${v.value} <small>${v.unit}</small></div>
        <div style="margin: 14px 0; line-height: 1.6;">
          <p style="color: #e5e7eb; margin-bottom: 10px; font-size: 13px;">${v.description}</p>
          <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); padding: 12px 14px; border-radius: 8px; font-size: 11px; color: #9ca3af; display: grid; gap: 6px;">
            <div><strong style="color: #fff;">Operational Target:</strong> ${v.note}</div>
            <div><strong style="color: #fff;">Sensor Telemetry Source:</strong> ${v.source || 'Optical / Wearable Biosensor Suite'}</div>
            <div><strong style="color: #fff;">Flight Mode:</strong> ${currentMode === 'realtime' ? '⚡ Live Telemetry Stream (OrbitWatch-01 BLE 125Hz)' : '🔬 Trial Demo Baseline Sample'}</div>
          </div>
        </div>
      `);
    })
  );
}

// ── 5 Operational ML Models Rendering ───────────────────────────────────────
function renderModels(showDialog) {
  const container = document.querySelector('#models-grid');
  if (!container) return;
  container.innerHTML = currentModels
    .map(
      m => `
    <div class="model-card" data-model="${m.id}" role="button" tabindex="0">
      <div class="model-header">
        <span class="model-title">${icon('brain')} ${m.name}</span>
        <span class="model-badge">${m.badge}</span>
      </div>
      <div class="model-output" id="model-output-${m.id}">${m.current}</div>
      <div class="model-meta">
        <span><strong>Dataset:</strong> ${m.dataset}</span>
        <span><strong>Metric:</strong> ${m.metric}</span>
      </div>
    </div>`
    )
    .join('');

  document.querySelectorAll('[data-model]').forEach(card => {
    card.addEventListener('click', () => {
      const m = currentModels.find(item => item.id === card.dataset.model);
      if (!m) return;
      showDialog(`
        <h2>${m.name}</h2>
        <div class="dialog-reading" style="font-size: 20px;">${m.current}</div>
        <div style="margin: 14px 0; line-height: 1.6;">
          <p style="color: #e5e7eb; margin-bottom: 12px; font-size: 13px;">${m.description}</p>
          <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); padding: 12px 14px; border-radius: 8px; font-size: 11px; color: #9ca3af; display: grid; gap: 6px;">
            <div><strong style="color: #fff;">Architecture:</strong> ${m.badge}</div>
            <div><strong style="color: #fff;">Validation Benchmark:</strong> ${m.metric} (${m.dataset})</div>
            <div><strong style="color: #fff;">Input Dimension:</strong> ${m.inputVector || 'Multi-modal Biometric Tensor'}</div>
            <div><strong style="color: #fff;">On-Device Latency:</strong> ${m.latency || '< 1.0 ms'}</div>
            <div><strong style="color: #fff;">Inference Engine:</strong> AstraIntelligenceEngine (Real-Time Sub-millisecond Execution)</div>
          </div>
        </div>
      `);
    });
  });
}

// ── Disease Detection Rendering ─────────────────────────────────────────────
function renderDiseases(showDialog) {
  const container = document.querySelector('#diseases-grid');
  if (!container) return;
  container.innerHTML = currentDiseases
    .map(d => {
      const badgeClass =
        d.severity === 'NOMINAL'
          ? 'badge-nominal'
          : d.severity === 'MONITORED'
          ? 'badge-monitored'
          : d.severity === 'ACTIVE PROTOCOL'
          ? 'badge-caution'
          : 'badge-alert';

      return `
      <div class="disease-card" data-disease="${d.id}" role="button" tabindex="0">
        <div>
          <div class="disease-top">
            <div>
              <span class="disease-category">${d.category}</span>
              <h3 class="disease-name">${d.name}</h3>
            </div>
            <span class="severity-badge ${badgeClass}" id="sev-${d.id}">${d.severity}</span>
          </div>
          <div class="disease-biomarkers" id="bio-${d.id}">Score: ${d.score || d.risk_score || 'Nominal'}</div>
          <p class="disease-preview">${d.mechanism || d.pathology}</p>
        </div>
        <span class="disease-action">
          View Flight Surgeon Protocol ${icon('arrowUpRight')}
        </span>
      </div>`;
    })
    .join('');

  document.querySelectorAll('[data-disease]').forEach(card => {
    card.addEventListener('click', () => {
      const d = currentDiseases.find(item => item.id === card.dataset.disease);
      if (!d) return;
      showDialog(`
        <h2>${d.name}</h2>
        <div style="display:flex; gap:10px; align-items:center; margin: 10px 0;">
          <span class="disease-category">${d.category}</span>
          <span class="severity-badge badge-nominal">${d.severity || d.risk_level || 'NOMINAL'}</span>
        </div>
        <div style="margin: 14px 0; line-height: 1.6;">
          <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); padding: 10px 12px; border-radius: 6px; font-size: 11px; margin-bottom: 12px; color: #9ca3af;">
            <strong style="color: #fff;">Telemetry Biomarkers Evaluated:</strong> ${d.biomarkers || 'Continuous Multi-Sensor Fusion'}
          </div>
          <h4 style="font-size: 12px; color: #b0b4c0; margin-bottom: 4px;">AEROSPACE PATHOLOGY & MECHANISM:</h4>
          <p style="font-size: 12px; color: #d1d5db; margin-bottom: 14px;">${d.mechanism || d.pathology}</p>
          <h4 style="font-size: 12px; color: #4ade80; margin-bottom: 4px;">NASA FLIGHT SURGEON COUNTERMEASURE:</h4>
          <p style="font-size: 12px; color: #d1d5db; background: rgba(34,197,94,0.06); border-left: 3px solid #22c55e; padding: 10px 12px; border-radius: 4px;">
            ${d.protocol}
          </p>
        </div>
      `);
    });
  });
}

// ── Mode Switcher & Smartwatch Detection ────────────────────────────────────
function initModeAndWatchControls(toast) {
  const btnDemo = document.querySelector('#btn-mode-demo');
  const btnRealtime = document.querySelector('#btn-mode-realtime');
  const watchPill = document.querySelector('#watch-status-pill');
  const btnToggleWatch = document.querySelector('#btn-toggle-watch');

  // Fetch initial smartwatch and mode status from backend
  fetch('/api/smartwatch/status')
    .then(r => r.json())
    .then(data => {
      smartwatchConnected = Boolean(data.connected);
      updateWatchUI(watchPill, btnToggleWatch);
    })
    .catch(() => {});

  if (btnDemo) {
    btnDemo.addEventListener('click', () => {
      setMode('demo', toast);
    });
  }

  if (btnRealtime) {
    btnRealtime.addEventListener('click', async () => {
      // Check if smartwatch is detected
      try {
        const res = await fetch('/api/smartwatch/status');
        const sw = await res.json();
        smartwatchConnected = Boolean(sw.connected);
        updateWatchUI(watchPill, btnToggleWatch);

        if (!smartwatchConnected) {
          toast('⚠️ Smartwatch not detected! No BLE stream found. Returning to Trial Demo mode.');
          setMode('demo', toast);
          return;
        }

        // Smartwatch detected: activate real-time mode
        setMode('realtime', toast);
      } catch (err) {
        toast('⚠️ Unable to connect to smartwatch service. Remaining in Demo mode.');
        setMode('demo', toast);
      }
    });
  }

  if (btnToggleWatch) {
    btnToggleWatch.addEventListener('click', async () => {
      const newState = !smartwatchConnected;
      try {
        const res = await fetch('/api/smartwatch/status', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ connected: newState })
        });
        const data = await res.json();
        smartwatchConnected = Boolean(data.smartwatch.connected);
        updateWatchUI(watchPill, btnToggleWatch);

        if (smartwatchConnected) {
          toast('✅ OrbitWatch-01 Connected via BLE 125Hz.');
        } else {
          toast('⚠️ OrbitWatch-01 Disconnected! (Simulated)');
          if (currentMode === 'realtime') {
            toast('⚠️ Smartwatch lost! Reverting to Trial Demo mode.');
            setMode('demo', toast);
          }
        }
      } catch (err) {
        toast('Connection toggle failed.');
      }
    });
  }
}

function updateWatchUI(watchPill, btnToggleWatch) {
  if (watchPill) {
    if (smartwatchConnected) {
      watchPill.className = 'watch-pill connected';
      watchPill.innerHTML = `<span class="status-dot" style="background:#22c55e"></span> OrbitWatch-01 (BLE 125Hz Connected)`;
    } else {
      watchPill.className = 'watch-pill disconnected';
      watchPill.innerHTML = `<span class="status-dot" style="background:#ef4444"></span> Smartwatch: Not Detected`;
    }
  }
  if (btnToggleWatch) {
    btnToggleWatch.textContent = smartwatchConnected ? 'Disconnect Watch' : 'Connect Watch';
  }
}

function setMode(mode, toast) {
  currentMode = mode;
  const btnDemo = document.querySelector('#btn-mode-demo');
  const btnRealtime = document.querySelector('#btn-mode-realtime');

  if (mode === 'realtime') {
    if (btnDemo) btnDemo.classList.remove('active');
    if (btnRealtime) btnRealtime.classList.add('active', 'realtime');
    toast('⚡ Real-Time Mode Active: Dynamic 2s streaming via OrbitWatch-01.');
    startRealTimeLoop();
  } else {
    if (btnRealtime) btnRealtime.classList.remove('active', 'realtime');
    if (btnDemo) btnDemo.classList.add('active');
    stopRealTimeLoop();
    resetToDemoBaseline();
    toast('🔬 Trial Demo Mode: Showing baseline astronaut fixtures.');
  }
}

// ── Dynamic 2-Second Real-Time Telemetry Loop ──────────────────────────────
function startRealTimeLoop() {
  stopRealTimeLoop();
  // Fetch immediately
  fetchLiveTelemetry();
  // Loop every 2 seconds
  realTimeInterval = setInterval(fetchLiveTelemetry, 2000);
}

function stopRealTimeLoop() {
  if (realTimeInterval) {
    clearInterval(realTimeInterval);
    realTimeInterval = null;
  }
}

async function fetchLiveTelemetry() {
  if (currentMode !== 'realtime' || !smartwatchConnected) return;

  try {
    const res = await fetch('/api/telemetry/live');
    if (!res.ok) return;
    const data = await res.json();
    const t = data.telemetry || {};

    // 1. Dynamic pulse effect on all vital cards
    document.querySelectorAll('.vital-card').forEach(card => {
      card.classList.remove('is-pulsing');
      void card.offsetWidth; // trigger reflow
      card.classList.add('is-pulsing');
    });

    // 2. Update Vitals
    updateVitalValue('heart', t.heart_rate_bpm || t.heart_rate || 74.2, 'bpm', 'Live BLE 125Hz');
    updateVitalValue('oxygen', t.spo2_percent || t.spo2 || 98.6, '%', 'Pulse Oximeter');
    updateVitalValue('temperature', t.core_temp_c || t.temperature || 36.85, '°C', 'Heat Flux Sensor');
    updateVitalValue('water', t.blood_water_percent || t.blood_water || 62.4, '%', 'Bioimpedance Hydration');
    updateVitalValue('pressure', t.systolic_bp ? `${Math.round(t.systolic_bp)}/${Math.round(t.diastolic_bp)}` : (t.blood_pressure || '120/78'), 'mmHg', 'Continuous BP');
    updateVitalValue('respiration', t.respiration_rate || 16.2, 'brpm', 'Transthoracic');
    updateVitalValue('hrv', t.hrv_rmssd || 48.5, 'ms', 'RMSSD Parasympathetic');

    // 3. Update 5 ML Models
    const act = t.activity && typeof t.activity === 'object' ? t.activity.activity_name : (t.activity || 'Resting');
    updateModelOutput('activity', act);

    const stress = t.stress && typeof t.stress === 'object' ? t.stress.stress_state : (t.stress || 'Baseline / Relaxed');
    updateModelOutput('stress', stress);

    const hrPred = t.heart_rate && typeof t.heart_rate === 'object' ? `${t.heart_rate.estimated_heart_rate_bpm} BPM` : `${t.heart_rate_bpm || 74.0} BPM`;
    updateModelOutput('heart', hrPred);

    const anom = t.anomaly_detection ? (t.anomaly_detection.anomaly_flag ? '⚠️ DIVERGENCE' : 'NOMINAL (Score: ' + (t.anomaly_detection.anomaly_score || 0.12) + ')') : 'Nominal Health State';
    updateModelOutput('anomaly', anom);

    const bio = t.space_bio && typeof t.space_bio === 'object' ? t.space_bio.biological_state : (t.space_bio || 'Orbital Spaceflight State');
    updateModelOutput('space_bio', bio);

    // 4. Update Disease Risks if returned
    if (data.disease_risks && Array.isArray(data.disease_risks)) {
      data.disease_risks.forEach(d => {
        const bioEl = document.querySelector(`#bio-${d.id}`);
        const sevEl = document.querySelector(`#sev-${d.id}`);
        if (bioEl) bioEl.textContent = d.biomarkers || `Risk Score: ${d.risk_score}/100`;
        if (sevEl) {
          sevEl.textContent = d.risk_level || 'NOMINAL';
        }
      });
    }
  } catch (err) {
    console.error('Error fetching real-time telemetry:', err);
  }
}

function updateVitalValue(id, val, unit, note) {
  const valEl = document.querySelector(`#val-${id}`);
  const noteEl = document.querySelector(`#note-${id}`);
  if (valEl) valEl.innerHTML = `${val}<small>${unit}</small>`;
  if (noteEl) noteEl.textContent = note;
}

function updateModelOutput(id, text) {
  const el = document.querySelector(`#model-output-${id}`);
  if (el) el.textContent = text;
}

function resetToDemoBaseline() {
  defaultVitals.forEach(v => {
    updateVitalValue(v.id, v.value, v.unit, v.note);
  });
  defaultModels.forEach(m => {
    updateModelOutput(m.id, m.current);
  });
  defaultDiseases.forEach(d => {
    const bioEl = document.querySelector(`#bio-${d.id}`);
    const sevEl = document.querySelector(`#sev-${d.id}`);
    if (bioEl) bioEl.textContent = `Score: ${d.score}`;
    if (sevEl) sevEl.textContent = d.severity;
  });
}

// ── Online Learning Integration ─────────────────────────────────────────────
function initOnlineLearning(toast) {
  const btnRunStep = document.querySelector('#btn-run-ol-step');
  const olUpdates = document.querySelector('#ol-updates');
  const olAccuracy = document.querySelector('#ol-accuracy');
  const olDrift = document.querySelector('#ol-drift');

  async function refreshOLStats() {
    try {
      const res = await fetch('/api/online_learn/stats');
      if (!res.ok) return;
      const stats = await res.json();
      if (olUpdates) olUpdates.textContent = stats.n_updates;
      if (olAccuracy) olAccuracy.textContent = stats.rolling_accuracy !== null ? `${(stats.rolling_accuracy * 100).toFixed(1)}%` : 'Calibrating';
      if (olDrift) {
        olDrift.textContent = stats.concept_drift_detected ? '⚠️ DRIFT DETECTED' : 'STABLE (No Drift)';
        olDrift.style.color = stats.concept_drift_detected ? '#f87171' : '#4ade80';
      }
    } catch {}
  }

  if (btnRunStep) {
    btnRunStep.addEventListener('click', async () => {
      try {
        const res = await fetch('/api/online_learn', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            heart_rate: 76.5,
            temperature: 36.9,
            respiration_rate: 16.5,
            label: 'relaxed'
          })
        });
        const data = await res.json();
        toast(`✅ Online SGD Updated (Batch #${data.n_updates}). Rolling Acc: ${(data.rolling_accuracy * 100).toFixed(1)}%`);
        refreshOLStats();
      } catch (err) {
        toast('Online learning update failed.');
      }
    });
  }

  refreshOLStats();
}

// ── Routines & Heart Rate Chart ─────────────────────────────────────────────
function renderRoutines() {
  const list = document.querySelector('#routine-list');
  if (!list) return;
  list.innerHTML = routines
    .map(
      (r, i) => `
    <label class="routine-row">
      <input type="checkbox" aria-label="Mark ${r.title.toLowerCase()} complete" data-routine="${i}">
      <span>
        <strong>${r.title}</strong>
        <small>${r.description}</small>
      </span>
      <span>${r.time}</span>
    </label>`
    )
    .join('');

  list.addEventListener('change', () => {
    const checked = document.querySelectorAll('[data-routine]:checked').length;
    const countEl = document.querySelector('#routine-count');
    if (countEl) countEl.textContent = `${checked} / ${routines.length}`;
  });

  document.querySelectorAll('[data-range]').forEach(b =>
    b.addEventListener('click', () => renderChart(b.dataset.range))
  );
}

function renderChart(range) {
  const week = range === 'week';
  const values = week
    ? [71, 69, 70, 67, 69, 66, 68]
    : [66, 65, 68, 67, 72, 68, 69, 66, 65, 67, 69, 68, 67, 70, 68, 69, 66, 68, 67, 68, 66, 68, 69, 68];
  const points = values.map((v, i) => `${(i * 600) / (values.length - 1)},${70 - (v - 63) * 6}`).join(' ');

  const chartEl = document.querySelector('#trend-chart');
  if (chartEl) {
    chartEl.innerHTML = `
      <svg viewBox="0 0 600 80" preserveAspectRatio="none" role="img" aria-label="${week ? 'Seven day' : '24 hour'} resting heart rate chart">
        <defs>
          <linearGradient id="chart-fill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#fff" stop-opacity=".15"/>
            <stop offset="100%" stop-color="#fff" stop-opacity="0"/>
          </linearGradient>
        </defs>
        <polygon points="0,80 ${points} 600,80" fill="url(#chart-fill)"/>
        <polyline points="${points}" fill="none" stroke="#4ade80" stroke-width="1.8" vector-effect="non-scaling-stroke"/>
      </svg>`;
  }

  const axisEl = document.querySelector('#chart-axis');
  if (axisEl) {
    axisEl.innerHTML = (week
      ? ['SAT', 'SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI']
      : ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', '23:00']
    )
      .map(t => `<span>${t}</span>`)
      .join('');
  }

  const valEl = document.querySelector('#trend-value');
  if (valEl) valEl.innerHTML = `${week ? '69' : '68'} <small>bpm</small>`;

  const descEl = document.querySelector('#trend-description');
  if (descEl) descEl.textContent = week ? "This week's sample average" : "Today's sample average";

  document.querySelectorAll('[data-range]').forEach(b =>
    b.setAttribute('aria-pressed', String(b.dataset.range === range))
  );
}
