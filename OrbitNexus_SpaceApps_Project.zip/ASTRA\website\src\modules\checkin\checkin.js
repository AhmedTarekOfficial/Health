import { addEntry } from '../mission/log.js';
import { initVoice } from './voice.js';
import { icon } from '../../shared/icons.js';

export function initCheckin(toast) {
  const form = document.querySelector('#feeling-form');
  const input = document.querySelector('#feeling-input');
  const dialog = document.querySelector('#writing-dialog');
  const opener = document.querySelector('#open-writing');
  let closeTimer;

  function saveCheckin(note, energy, { quiet = false } = {}) {
    addEntry(energy ? `Clinical Observation · ${energy} exertion` : 'Clinical Observation', note);
    const feedback = document.querySelector('#feeling-feedback');
    if (feedback) {
      feedback.hidden = false;
      feedback.textContent = 'Clinical observation archived in mission log.';
    }
    const routine = document.querySelector('[data-routine="3"]');
    if (routine) {
      routine.checked = true;
      routine.dispatchEvent(new Event('change', { bubbles: true }));
    }
    if (!quiet) toast('Clinical observation archived.');
  }

  function resizeInput() {
    input.style.height = 'auto';
    input.style.height = `${Math.min(input.scrollHeight, 300)}px`;
  }

  function openWriting(text) {
    voice.pauseForWriting();
    if (typeof text === 'string') {
      input.value = text;
      input.setCustomValidity('');
    }
    if (dialog.open) return;
    clearTimeout(closeTimer);
    dialog.classList.remove('closing');
    dialog.showModal();
    resizeInput();
    input.focus();
  }

  function closeWriting() {
    if (!dialog.open || dialog.classList.contains('closing')) return;
    dialog.classList.add('closing');
    const duration = matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 160;
    closeTimer = setTimeout(() => {
      dialog.close();
      voice.resumeAfterWriting();
      dialog.classList.remove('closing');
      if (opener) opener.focus({ preventScroll: true });
    }, duration);
  }

  const voice = initVoice({ saveCheckin, openWriting });

  if (opener) opener.addEventListener('click', () => openWriting());
  const closeBtn = document.querySelector('#close-writing');
  if (closeBtn) closeBtn.addEventListener('click', closeWriting);

  if (dialog) {
    dialog.addEventListener('cancel', event => {
      event.preventDefault();
      closeWriting();
    });
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const rect = dialog.getBoundingClientRect();
      if (
        event.clientX < rect.left ||
        event.clientX > rect.right ||
        event.clientY < rect.top ||
        event.clientY > rect.bottom
      )
        closeWriting();
    });
  }

  if (input) {
    input.addEventListener('input', () => {
      input.setCustomValidity('');
      resizeInput();
    });
  }

  if (form) {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const note = input.value.trim();
      if (!note) {
        input.setCustomValidity('Add clinical observations.');
        input.reportValidity();
        return;
      }
      saveCheckin(note, new FormData(form).get('energy'));
      form.reset();
      input.style.height = '';
      closeWriting();
    });
  }

  // Initialize the OrbitNexus AI Chatbot & Voice Bridge
  initAIChatbot(voice, toast);
}

function initAIChatbot(voice, toast) {
  const chatForm = document.querySelector('#chat-form');
  const chatInput = document.querySelector('#chat-input');
  const chatHistory = document.querySelector('#chat-history');
  const btnVoiceChat = document.querySelector('#btn-voice-chat');
  const btnSimulateVoice = document.querySelector('#btn-simulate-voice');
  const promptChips = document.querySelectorAll('.chip-btn');

  // Handle Voice Toggle inside Chat
  if (btnVoiceChat && voice && voice.session) {
    btnVoiceChat.addEventListener('click', () => {
      if (voice.session.enabled) {
        voice.session.disable();
        const text = (chatInput ? chatInput.value : '').trim();
        if (text) {
          submitChatMessage(text);
        } else {
          toast('Microphone paused.');
        }
      } else {
        voice.session.enable();
        toast('🎙️ Microphone active! Speak clearly now.');
      }
    });
  }

  // Simulated Voice Input for fallback & demonstration
  if (btnSimulateVoice) {
    btnSimulateVoice.addEventListener('click', () => {
      const sampleText = "Commander Vance requesting acute cephalad fluid shift and SANS risk assessment";
      simulateVoiceTyping(sampleText);
    });
  }

  function simulateVoiceTyping(fullText) {
    if (!chatInput) return;
    chatInput.value = '';
    chatInput.style.borderColor = '#4ade80';
    chatInput.style.boxShadow = '0 0 12px rgba(74, 222, 128, 0.35)';
    toast('🎙️ Transcribing simulated astronaut voice input...');

    let i = 0;
    const interval = setInterval(() => {
      if (i < fullText.length) {
        chatInput.value += fullText.charAt(i);
        chatInput.dispatchEvent(new Event('input', { bubbles: true }));
        i++;
      } else {
        clearInterval(interval);
        chatInput.style.borderColor = '';
        chatInput.style.boxShadow = '';
        setTimeout(() => {
          submitChatMessage(fullText);
        }, 400);
      }
    }, 25);
  }

  // Quick Astronaut Medical Prompts
  promptChips.forEach(chip => {
    chip.addEventListener('click', () => {
      const prompt = chip.dataset.prompt || chip.textContent.trim();
      if (chatInput) {
        chatInput.value = prompt;
        submitChatMessage(prompt);
      }
    });
  });

  // Handle Chat Submission
  if (chatForm) {
    chatForm.addEventListener('submit', event => {
      event.preventDefault();
      const text = (chatInput ? chatInput.value : '').trim();
      if (!text) return;
      submitChatMessage(text);
    });
  }

  async function submitChatMessage(message) {
    if (!message) return;
    appendChatBubble('user', 'Astronaut Alex', message);
    if (chatInput) chatInput.value = '';

    const typingId = appendChatBubble('ai', 'OrbitNexus AI', 'Analyzing astronaut bio-telemetry & flight constraints...');

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message })
      });
      const data = await res.json();
      const reply = data.reply || data.error || 'Medical intelligence offline.';

      const typingEl = document.querySelector(`#${typingId}`);
      if (typingEl) {
        typingEl.querySelector('.bubble-text').innerHTML = formatMarkdown(reply);
      }

      // Read aloud via SpeechSynthesis if supported
      if (window.speechSynthesis && data.voice && data.voice.text) {
        try {
          window.speechSynthesis.cancel();
          const utterance = new SpeechSynthesisUtterance(data.voice.text);
          utterance.rate = 1.05;
          window.speechSynthesis.speak(utterance);
        } catch {}
      }

      addEntry('OrbitNexus AI Clinical Analysis', `Astronaut: ${message}\n\nOrbitNexus: ${reply}`);
    } catch (err) {
      const typingEl = document.querySelector(`#${typingId}`);
      if (typingEl) {
        typingEl.querySelector('.bubble-text').textContent = '⚠️ Network error communicating with OrbitNexus AI.';
      }
    }
  }

  function appendChatBubble(role, sender, text) {
    if (!chatHistory) return '';
    const id = `bubble-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    const bubble = document.createElement('div');
    bubble.className = `chat-bubble ${role}`;
    bubble.id = id;
    bubble.innerHTML = `
      <div class="sender">${sender}</div>
      <div class="bubble-text">${formatMarkdown(text)}</div>
    `;
    chatHistory.appendChild(bubble);
    chatHistory.scrollTop = chatHistory.scrollHeight;
    return id;
  }

  function formatMarkdown(text) {
    if (!text) return '';
    return text
      .replace(/\n\n/g, '<br><br>')
      .replace(/\n/g, '<br>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>');
  }
}
